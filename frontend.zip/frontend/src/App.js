import React from 'react';
import Tasks from './components/Tasks';

function App() {
  return (
    <div className="App">
      <Tasks />
    </div>
  );
}

export default App;
