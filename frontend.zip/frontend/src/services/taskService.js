import axios from 'axios';

const API_URL = 'http://localhost:8000/api'; // Adjust this URL based on your Laravel server configuration

const axiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin':'*'
  },
});

export const getAllTasks = async () => {
  try {
    const response = await axiosInstance.get('/tasks');
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const createTask = async (taskData) => {
    try {
      const response = await axiosInstance.post('/tasks', taskData);
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  
  export const updateTask = async (taskId, taskData) => {
    try {
      const response = await axiosInstance.put(`/tasks/${taskId}`, taskData);
      return response.data;
    } catch (error) {
      throw error;
    }
  };
  
  export const deleteTask = async (taskId) => {
    try {
      const response = await axiosInstance.delete(`/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  };

