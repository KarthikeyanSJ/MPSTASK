import React, { useEffect,useState} from 'react';
import { createTask,getAllTasks,deleteTask ,updateTask} from '../services/taskService';
import './style.css';
function TaskList() {
    const [tasks, setTasks] = useState([]);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [editingTaskId, setEditingTaskId] = useState(null);
  
    useEffect(() => {
      fetchTasks();
    }, []);
  
    const fetchTasks = async () => {
      try {
        const data = await getAllTasks();
        setTasks(data);
      } catch (error) {
        console.error('Error fetching tasks:', error);
      }
    };
  
    const handleCreateTask = async (e) => {
      e.preventDefault();
  
      try {
        const newTask = await createTask({ title, description });
        console.log('New task created:', newTask);
  
        setTitle('');
        setDescription('');
  
        fetchTasks();
      } catch (error) {
        console.error('Error creating task:', error);
      }
    };
  
    const handleDeleteTask = async (taskId) => {
      try {
        await deleteTask(taskId);
        console.log('Task deleted:', taskId);
  
        fetchTasks();
      } catch (error) {
        console.error('Error deleting task:', error);
      }
    };

    const handleEditTask = (taskId) => {
        setEditingTaskId(taskId);
        
        const taskToEdit = tasks.find(task => task.id === taskId);
        setTitle(taskToEdit.title);
        setDescription(taskToEdit.description);
      };

      
    const handleUpdateTask = async () => {
        try {
          await updateTask(editingTaskId, { title, description });
          console.log('Task updated:', editingTaskId);
    
          setTitle('');
          setDescription('');
          setEditingTaskId(null);
    
          fetchTasks();
        } catch (error) {
          console.error('Error updating task:', error);
        }
    };
    
    const showTask = (taskId)=>{
        const taskToEdit = tasks.find(task => task.id === taskId);
        setTitle(taskToEdit.title);
        setDescription(taskToEdit.description);
    }
  
    return (
      <div>
        <h3 style={{textAlign:"center"}}>Please add Note:</h3>
        <form className="formclass" onSubmit={handleCreateTask}>
          <input
            type="text"
            placeholder="Title"
            value={title}
            className="input-field"
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            placeholder="Description"
            value={description}
            className="textarea-field"
            onChange={(e) => setDescription(e.target.value)}
          ></textarea>
          <button type="submit">Create Note</button>
        </form>
        
        <h1>Note List:</h1>
        <table>
          <thead>
            <tr>
              <th>Title</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map(task => (
              <tr key={task.id}>
                <td>
                {editingTaskId === task.id ? (
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                ) : (
                  task.title
                )}
              </td>
              <td>
                {editingTaskId === task.id ? (
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  ></textarea>
                ) : (
                  task.description
                )}
              </td>
              <td>
                {editingTaskId === task.id ? (
                  <>
                    <button onClick={handleUpdateTask}>Save</button>
                    <button onClick={() => setEditingTaskId(null)}>Cancel</button>
                  </>
                ) : (
                  <>
                    <button onClick={() => showTask(task.id)}>Show</button>
                    <button onClick={() => handleEditTask(task.id)}>Edit</button>
                    <button onClick={() => handleDeleteTask(task.id)}>Delete</button>
                  </>
                )}
              </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
  
  export default TaskList;